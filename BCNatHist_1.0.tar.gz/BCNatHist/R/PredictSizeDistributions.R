
PredictSizeDistributions <- function(model, data, d_max = 10, regular_pred = NULL,  
                            base_variables = list(
                              entry = "entry", exit = "exit", is_case = "case", 
                              mode = "mode", size = "size", scr_hist = "scr"),
                            gauss_kronrod_set = 6, gauss_leguerre_set = 4, followup = NULL,
                            d0 = 0.5, n_cores = parallel::detectCores() - 1){

  `%dopar%` <- foreach::`%dopar%`
  
  gkmat <- gknodes(gauss_kronrod_set)
  glmat <- glnodes(gauss_leguerre_set)
  
  dv <- function(d) {
    pi / 6 * d ^ 3
  }
  
  v_max <- dv(d_max)
  v0 <- dv(d0)
  
  newpar <- BuildParameters(model$par, model, data)
  data <- MatchDataVariables(data, base_variables, include_prevalent_screen = FALSE)
  if(is.null(followup)) {
    followup <- data$exit
  } else {
    followup <- data$entry + followup
  }
  
  
  ix <- seq_along(data$entry)
  cl <- parallel::makePSOCKcluster(n_cores)
  doParallel::registerDoParallel(cl)
  
  if (is.null(regular_pred)) {
    cat("Predicting...1/7    \r")
    q <- foreach::foreach(i=itertools::isplitVector(ix, chunks = n_cores), 
                          .combine = c) %dopar%
      vapply(i, function(j) {
        CalcCensCase(data$entry[j],data$e_scr[[j]], newpar[j, ],
                                          gkmat$x, gkmat$w, glmat$x, glmat$w)
        }, FUN.VALUE = 0)
    cat("Predicting...2/7    \r")
    # overall <- 1 - foreach::foreach(i=itertools::isplitVector(ix, chunks = n_cores), 
    #                                 .combine = c) %dopar% {
    #                                   vapply(i, function(j) {
    #                                     CalcCensCase(followup[j], data$scr[[j]], newpar[j, ],
    #                                                  gkmat$x, gkmat$w, glmat$x, glmat$w) 
    #                                   }, FUN.VALUE = 0)} / q
    # cat("Predicting...3/7    \r")
    # no_overall <- 1 - foreach::foreach(i=itertools::isplitVector(ix, chunks = n_cores), 
    #                                    .combine = c) %dopar% {
    #                                      vapply(i, function(j) {
    #                                        CalcCensCase(followup[j], data$e_scr[[j]], newpar[j, ],
    #                                                     gkmat$x, gkmat$w, glmat$x, glmat$w) 
    #                                      }, FUN.VALUE = 0)} / q
  } else {
    q <- regular_pred$surv
    # overall <- regular_pred$risk_attend
    # no_overall <- regular_pred$risk_noattend
  }
  screensize <- foreach::foreach(i=itertools::isplitVector(ix, chunks = n_cores), 
                                 .combine = c) %dopar% {
                jd.grid <- expand.grid(d=glmat$x+d0, j=i)
                mapply(function(j, d) {pi * d^2 / 2 * 
                    CalculateScreenCase(data$scr[[j]][1], dv(d), data$scr[[j]], 
                                        newpar[j, ], gkmat$x, gkmat$w) / q[j]},
                       jd.grid$j, jd.grid$d)}
  intsize1 <-  foreach::foreach(i=itertools::isplitVector(ix, chunks = n_cores), 
                                .combine = c) %dopar% {
               vapply(i, function(j) {
                 ud.grid <- expand.grid(u=(gkmat$x * (data$scr[[j]][1]-data$entry[j])/2 + data$scr[[j]][1]+data$entry[j])/2,
                                        d=glmat$x + d0)
                 wts <- rep(1, length(glmat$x)) %*% t((data$scr[[j]][1]-data$entry[j])/2 * gkmat$w)
                 temp <- mapply(function(u, d) {CalculateSymptCase(u, dv(d), data$e.scr[[j]], newpar[j, ], gkmat$x, gkmat$w) * pi * d ^ 2 / 2  / q[j]},
                                ud.grid$u, ud.grid$d)
                 rowSums(matrix(temp, nrow(wts), , T) * wts, na.rm = T)
               }, FUN.VALUE = 0)}
  intsize2 <-  foreach::foreach(i=itertools::isplitVector(ix, chunks = n_cores), 
                                .combine = c) %dopar% {
               vapply(i, function(j) {
                 ud.grid <- expand.grid(u=(gkmat$x * (data$exit[j]-data$scr[[j]][1]) + data$exit[j]+data$scr[[j]][1])/2,
                                        d=glmat$x + d0)
                 wts <- rep(1, length(glmat$x)) %*% t((data$exit[j]-data$scr[[j]][1])/2 * gkmat61$w)
                 temp <- mapply(function(u, d) {CalculateSymptCase(u, dv(d), data$scr[[j]], newpar[j, ], gkmat$x, gkmat$w) * pi * d^2 / 2  / q[j] },
                                ud.grid$u, ud.grid$d)
                 rowSums(matrix(temp, nrow(wts), , T) * wts, na.rm = T)
               }, FUN.VALUE = 0)}
  stopCluster(cl)
  is_screen <- as.numeric(data$mode == 1)
  is_screen[is.na(is_screen)] <- 0
  is_interval <- as.numeric(data$mode == 0)
  is_interval[is.na(is_interval)] <- 0

  #colnames(out) <- c('studieid', 'age', 'surv', 'next_scr', 'risk_noscr', 'risk_overall', 'risk_screen', 'risk_interval', 'd10_noscr', 'd10_scr', 'case', 'is_screen', 'is_interval')
  cat("Prediction successful!\n")
  list(screen_size = matrix(screensize, length(ix), byrow = T),
  int_size = matrix(intsize1, length(ix), byrow = T) + matrix(intsize2, length(ix), byrow = T))
}

