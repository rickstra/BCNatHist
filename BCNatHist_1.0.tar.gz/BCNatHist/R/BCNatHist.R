#' BCNatHist: A package for computating the notorious bar statistic.
#'
#' The mypackage package provides three categories of important functions:
#' foo, bar and baz.
#' 
#' @section Mypackage functions:
#' The mypackage functions ...
#'
#' @docType package
#' @name BCNatHist
#' @useDynLib BCNatHist, .registration=TRUE
#' @importFrom Rcpp evalCpp
NULL